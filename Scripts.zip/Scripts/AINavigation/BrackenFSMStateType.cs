public enum BrackenFSMStateType
{
    PATROLLING = 0,
    INTERESTED = 1,
    SHY = 2,
    AGGRESSIVE = 3
}
