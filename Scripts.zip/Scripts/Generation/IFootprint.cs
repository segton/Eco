using UnityEngine;

public interface IFootprint
{

    Vector2Int Size { get; }
}
