﻿public enum PlayerState
{
    Idle,
    Walk,
    Run,
    Punch,
    ReverseWalk,
}